you can load the environment either by:

conda env update --name new_environment_name --file environment.yml

or

conda create --name new_environment_name --file spec_file.txt